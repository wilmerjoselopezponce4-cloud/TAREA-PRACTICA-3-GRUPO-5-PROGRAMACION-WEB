<?php
declare(strict_types=1);
require __DIR__.'/../includes/app.php';
if (!isset($_SESSION['auth_user'])) {
    header('Location: login.php');
    exit;
}
$user = $_SESSION['auth_user'];
$realMysql = ($user['mode'] ?? '') === 'mysql';
page_head('Área privada del Grupo 5','EJERCICIO 06 · ACCESO AUTORIZADO','Panel de sesión para los usuarios del Grupo 5.','ejercicios');
?>
<div class="exercise-content"><section class="surface">
  <div class="alert <?php echo $realMysql ? 'success' : 'info'; ?>">
    <?php echo $realMysql
        ? '✓ Inicio de sesión validado con MySQL y PHP.'
        : '✓ Acceso correcto en modo demostración local. MySQL no estaba disponible: este acceso no verifica datos en MySQL.'; ?>
  </div>
  <p class="eyebrow">PANEL DEL USUARIO</p>
  <h2>¡Hola, <?php echo e($user['nombre']); ?>!</h2>
  <p class="section-description">Sesión iniciada con la cuenta: <strong><?php echo e($user['email']); ?></strong>.</p>
  <div class="two-col">
     <div class="info-card"><h3>Estado de sesión</h3><p>PHP mantiene los datos de la sesión hasta que cierras sesión.</p></div>
     <div class="info-card"><h3><?php echo $realMysql ? 'Autenticación MySQL' : 'Prueba sin MySQL'; ?></h3>
       <p><?php echo $realMysql
          ? 'Las contraseñas cifradas se verifican mediante password_verify() y consultas preparadas PDO.'
          : 'Las credenciales ficticias se verificaron únicamente en este equipo. Para comprobar el requisito MySQL, inicia MySQL y utiliza el instalador.'; ?></p>
     </div>
  </div>
  <?php if (!$realMysql): ?><p class="mt-25"><a href="../database/instalar.php" class="text-link">Configurar la base MySQL ↗</a></p><?php endif; ?>
  <form method="post" action="logout.php" class="mt-25"><input type="hidden" name="csrf" value="<?php echo e(csrf_token()); ?>"><button class="btn dark">Cerrar sesión →</button></form>
</section></div>
<?php page_foot(); ?>
