'use strict';
const menuBtn = document.getElementById('nav-toggle');
const nav = document.getElementById('main-nav');
if (menuBtn && nav) {
 menuBtn.addEventListener('click', () => { const active = nav.classList.toggle('open'); menuBtn.setAttribute('aria-expanded', String(active)); menuBtn.textContent = active ? '✕' : '☰'; });
 nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {nav.classList.remove('open');menuBtn.setAttribute('aria-expanded','false');menuBtn.textContent='☰';}));
}
